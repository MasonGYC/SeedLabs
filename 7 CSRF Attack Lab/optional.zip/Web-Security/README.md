Requirements: any machine with python/python3

General Info:

Webapplication is created using Flask web framework
Database used is sqlite3

install all the required libraries using this command

# pip install -r requirements.txt

start the webserver using this command

# python server.py

Exercise:

1. go to http://127.0.0.1/admin/contacts why this is vulnerable and can implement a fix in the code.

2. register and login in as a new user and try to upload an image file where the name of the file matches to existing name(for example 4.jpg) and why is this considered vulnerable and can you implement a fix in the code.

3. Try to understand how editing a comment works in the application and can you edit a comment posted by someone(Meeran for example) without logging in as Meeran. And how does CSRF token can mitigate this illegitimate behaviour.
