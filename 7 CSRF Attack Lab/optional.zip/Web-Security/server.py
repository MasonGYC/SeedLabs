'author: Mohamed Meeran'
#https://shorturl.at/itEJS
BANNER = r"""
      o__ __o       o__ __o      o__ __o      
     /v     v\     /v     v\    <|     v\     
    />       <\   />       <\   / \     <\    
  o/             _\o____        \o/       \o  
 <|                   \_\__o__   |         |> 
  \\                        \   / \       //  
    \         /   \         /   \o/      /    
     o       o     o       o     |      o     
     <\__ __/>     <\__ __/>    / \  __/>


"""
print(BANNER)

import sqlite3,hashlib,random,string,datetime,os,time
from flask import Flask,request,session,g,redirect,url_for,abort,render_template,flash,make_response
from jinja2 import Environment

DATABASE = 'ns.db'
SECRET_KEY = 'Network Security'
name =  'Network Security'
now = datetime.datetime.today()
date = str(now.year)+'-'+str(now.month)+'-'+str(now.day)
app = Flask(__name__)
Jinja2 = Environment()
app.config.from_object(__name__)

def hash(data):
    return hashlib.md5(data.encode('ascii')).hexdigest()

def connect_db():
    return sqlite3.connect(app.config['DATABASE'])

def init_db():
    with closing(connect_db()) as db:
        with app.open_resource('schema.sql',mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

@app.before_request
def before_request():
    g.db = connect_db()

@app.teardown_request
def teardown_request(exception):
    db = getattr(g,'db',None)
    if db is not None:
        db.close()
        
@app.before_request
def before_request():
    g.request_start_time = time.time()
    g.request_time = lambda: "%.5fs" % (time.time() - g.request_start_time)

@app.errorhandler(404)
def not_found(e):
    render_template("404.html")

@app.route('/')
@app.route('/home')
@app.route('/index.html')
def index():
    cur = g.db.execute('select id, feedback, author, date from comments order by id desc limit 8')
    a = cur.fetchall()
    entries = [dict(id=row[0],feedback=row[1], author=row[2], d=row[3]) for row in a]
    response=make_response(render_template('index.html',entries=entries,Name=name))
    return response

@app.route('/img/<id>')
def idimg(id):
    if 'user' not in session:
        response = make_response("Need to login to view individual images")
    else:
        cur = g.db.execute("select id,link,author,date from img where id = %s" %id)
        a = cur.fetchall()
        entries = [dict(id=row[0],link=row[1],author=row[2],d=row[3]) for row in a]
        id = str(id)
        response = make_response(render_template('image.html',entries=entries,Name=name))
    return response

@app.route('/image')
def img():
    cur = g.db.execute("select id,link from img order by id desc")
    a = cur.fetchall()
    entries = [dict(id=row[0],link=row[1]) for row in a]
    return render_template('img.html',entries=entries,Name=name)

@app.route('/image/delete/<id>',methods=['POST'])
def delete_image(id):
    if session.get('user')[0]:
        g.db.execute("DELETE from img where id=%s"%id)
        g.db.commit()
        return redirect(url_for('index'))

@app.route('/comments')
def posts():
    cur = g.db.execute('select id, feedback, author, date from comments order by id desc')
    a = cur.fetchall()
    entries = [dict(id=row[0],comments=row[1], author=row[2], d=row[3]) for row in a]
    return render_template('index.html',entries=entries,Name=name)

@app.route('/add', methods=['POST'])
def add_entry():
    if not session.get('user'):
        abort(401)
    g.db.execute('insert into comments (feedback, author, date) values ( ?, ?, ?)',
                [request.form['text'],session['user'][0],str(date)])
    g.db.commit()
    return redirect(url_for('index'))

@app.route('/login/delete/<id>',methods=['POST'])
def delete(id):
    if session.get('user')[0]:
        g.db.execute("DELETE from comments where id=%s"%id)
        g.db.commit()
        return redirect(url_for('index'))

@app.route('/login/ok/<id>',methods=['POST'])
def ok(id):
    if session.get('user')[0]:
        g.db.execute("UPDATE comments SET feedback=? WHERE id= ? ",[request.form['text'],id])
        g.db.commit()
        return redirect(url_for('index'))
    else:
        return ''
    
@app.route('/login/edit/<id>')
def edite(id):
    error = None
    if session.get('user')[0]:
        cur = g.db.execute('select id, feedback,author from comments where id = {}'.format(id))
        a = cur.fetchall()
        entries = [dict(id=row[0], feedback=row[1], author=row[2]) for row in a]    
        return render_template('edit.html', Name=name, entries=entries, user_session=session['user'][0])
    else:
        return ''

@app.route('/login', methods=['GET', 'POST'])
def login():
    cur = g.db.execute('select id, feedback, date, author from comments order by id desc')
    a = cur.fetchall()
    entries = [dict(id=row[0],feedback=row[1],d=row[2],author=row[3]) for row in a]
    error = None
    response=make_response(render_template('login.html',error=error))
    status = 200
    if session.get('user') != 'Admin':
        if request.method == 'POST':
            c = g.db.cursor()
            username = request.form['username']
            password = hash(request.form['password'])
            c.execute("SELECT * FROM users WHERE username='%s' AND password='%s'" %
                  (username, password))
            rval=c.fetchone()
            cur = g.db.execute("select username,password from users")
            a = cur.fetchall()
            users = [dict(username=row[0],password=row[1]) for row in a]	     
            if username == 'Admin' and password == app.adminhash:
                rval=('Admin','Admin')
            if rval:
                session['user'] = rval
                flash('Login Success!')
                return render_template('feedback.html', error=error,entries=entries,user_session=session['user'][0]),303
            else:
            	return render_template('login.html', error='Username or password incorrect!')

        elif session.get('user'):
            return render_template('feedback.html', error=error,entries=entries,user_session=session['user'][0])
    return response,status

@app.route('/register')
def register():
    if 'user' in session:
    	return make_response("You have already logged in as a legitimate user")
    username = request.args.get('username')
    password = request.args.get('password')
    if username and password != '':
    	password= hash(password)
    	conn = sqlite3.connect('ns.db')
    	c = conn.cursor()
    	c.execute("select username,password from users")
    	a = c.fetchall()
    	usernames = [item[0] for item in a]
    	if all(element != username for element in usernames):
    		c.execute("insert into users (username,password) values (?,?)",(username,password))
    		conn.commit()
    		return redirect(url_for('index'))
    	else:
    		return make_response("Usernames have already been used")
    return render_template('register.html', Name=name)

@app.route('/contact',methods=['GET','POST'])
def contact():
    if request.method == 'POST':
        first_name = request.form['first_name']
        email = request.form['email']
        phone = request.form['phone']
        message = request.form['message']
        cur = g.db.execute("SELECT name,email,phone,message FROM contact")
        if cur.fetchall():
            g.db.execute("insert into contact(name,email,phone,message) values (?,?,?,?)",(first_name,email,phone,message))
            g.db.commit()
            return redirect(url_for('index'))
    return render_template('contact.html',Name=name)

@app.route('/admin/contacts')
def users():
    cur = g.db.execute("select email,phone from contact")
    a = cur.fetchall()
    contacts = [dict(email=row[0],phone=row[1]) for row in a]
    return render_template('contacts.html',contacts=contacts,Name=name)

@app.route('/upload')
def upload():
    if 'user' not in session:
        return make_response("You need to login to upload")
    return render_template("file_upload_form.html")
    
@app.route('/success',methods=['POST'])
def success():
    if request.method == 'POST':
        os.chdir('static/uploads')
        f = request.files['file']
        f.save(f.filename)
        os.chdir('..')
        os.chdir('..')
        g.db.execute('insert into img (link,author,date) values (?,?,?)',
        	[f.filename,session['user'][0],str(date)])
        g.db.commit()
        return render_template("success.html", name = f.filename)
    
@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('You were logged out')
    return redirect(url_for('index'))

if __name__ == '__main__':
    meeranpass = 'meeran'
    app.adminhash,meeranhash = hash("admin"),hash(meeranpass)
    try:
        os.remove(app.config['DATABASE'])
    except OSError:
        pass
    image_files = ['1.jpg', '2.jpg', '3.jpg', '4.jpg']
    conn = sqlite3.connect(app.config['DATABASE'])
    c=conn.cursor()
    c.execute("create table if not exists img(link string, id INTEGER PRIMARY KEY AUTOINCREMENT,author string,date INTEGER)")
    for image_file in image_files:
        c.execute("INSERT INTO img (link,author,date) VALUES (?,?,?)", (image_file,'Meeran','2023-11-16',))
    c.execute("create table if not exists comments(id INTEGER PRIMARY KEY AUTOINCREMENT,feedback string, author string,date INTEGER)")
    c.execute("insert into comments(feedback,author,date) values ('This is my first comment','Meeran','2023-11-16')")
    c.execute("create table if not exists contact(name string, email string, phone string, message string)")
    c.execute("insert into contact(name,email,phone,message) values ('Test','test@test.com','123456789','Testing first message')")
    c.execute("create table if not exists users(username string, password string) ")
    c.execute("insert into users (username,password) values ('Admin','" + app.adminhash + "')")
    c.execute("insert into users (username,password) values ('Meeran','" + meeranhash + "')")
    conn.commit()
    app.config.update(SESSION_COOKIE_HTTPONLY=False)
    app.run(host='0.0.0.0',port=80,threaded= True,use_reloader=False)
